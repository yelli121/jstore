
/**
 * Write a description of class Jstore here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Jstore 
{
    public static void main(String[] args)
    {
        Short n1 =13;
        Short n2 = 14;
        System.out.println(n1.equals(n1));
        System.out.println(n2.equals(n2));
    }
}
            

