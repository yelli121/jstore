

/**
 * Write a description of class Invoice here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Invoice 
{
  public Invoice(){
    }
    //ganti int
    
  public int getId(){
      
      return 0;
    }
    
  public String getIdItem(){
     return "0";
    }
    //klo string return kosong
  public String getDate(){
        return "0";
     
    }
    
  public int getTotalPrice(){
        return 0;
    }
    
  public void setId (int Id){
      
    }
    
  public void setIdItem( int idItem){
      
    }
    
  public void setTotalPrice(int totalPrice){
      
    }
    
}