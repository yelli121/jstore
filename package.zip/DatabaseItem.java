
/**
 * Write a description of class DatabaseItem here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class DatabaseItem 
{
    
    public void addItem(){
    
    }
    
    public void removeItem(){
    }
    
    public void getItemDatabase(){
    }
    
    public void listItem(String Item){
    }
    
}

