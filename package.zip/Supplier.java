
/**
 * Write a description of class Supplier here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Supplier  
{
    public Supplier(){
      
    }
    
    public int getId(){
    return 0;
    }
    
    public String getName(){
    return "0";
    }

    public String getEmail(){
    return "0";
    }
    
    public String getPhoneNumber(){
    return "0";
    }
    
    public String getCity(){
    return "0";
    }
    
    public void setId(int id){
        
    }
    
    public void setName(String name){
        
    }
    
    public void setEmail(String email){
        
    }
    
    public void setPhoneNumber(String phoneNumber){
    
    }
    
    public void setCity(String city){
        
    }
    
   
}
