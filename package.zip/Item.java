
/**
 * Write a description of class Item here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Item
{
    public Item(){
        
    }
    
    public int getId() {
    return 0;
    }
    
    public String getName() {
    return "0"; 
    }
    
    public int getStock() {
    return 0;
    }
    
    public int getPrice() {
    return 0;
    }
    
    public int getCategory() {
    return 0;
    }
    
    public void setId(int id) {
        
    }
    
    public void setName(String name) {
        
    }
    
    public void setStock(int stock) {
        
    }
    
    public void setPrice(int price){
        
    }
    
    public void setCategory(String category){
        
    }
    
    
    
    
    
}



    



       
   
    

